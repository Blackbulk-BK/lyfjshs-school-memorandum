// Uploader page: upload, list, delete, logout
(async function () {
  if (!(await isAdmin())) { location.replace('/login'); return; }

  document.getElementById('admin-loading').hidden = true;
  document.getElementById('admin-content').hidden = false;

  const rows = document.getElementById('admin-rows');
  const form = document.getElementById('upload-form');
  const btn = document.getElementById('upload-btn');
  const msg = document.getElementById('upload-msg');
  let memos = [];

  async function loadMemos() {
    const { data } = await sb.from('memorandums').select('*').order('memo_date', { ascending: false });
    memos = data || [];
    rows.innerHTML = memos.map((m) => `
      <tr>
        <td><a href="/memo/${esc(m.id)}">${esc(m.memo_no)}</a></td>
        <td>${esc(m.title)}</td>
        <td class="date">${formatDate(m.memo_date)}</td>
        <td><button class="btn danger" data-id="${esc(m.id)}">Delete</button></td>
      </tr>`).join('');
  }

  // Delete (button clicks inside the table)
  rows.addEventListener('click', async (e) => {
    const id = e.target.dataset && e.target.dataset.id;
    if (!id) return;
    const memo = memos.find((m) => m.id === id);
    if (!memo || !confirm(`Delete ${memo.memo_no}?`)) return;
    await sb.storage.from(BUCKET).remove([memo.file_path]);
    await sb.from('memorandums').delete().eq('id', id);
    loadMemos();
  });

  // Upload
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const file = document.getElementById('file').files[0];
    if (!file) { msg.textContent = 'Please choose a file.'; return; }

    btn.disabled = true;
    btn.textContent = 'Uploading…';
    msg.textContent = '';

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const path = `${Date.now()}-${safeName}`;

    const up = await sb.storage.from(BUCKET).upload(path, file);
    if (up.error) {
      msg.textContent = up.error.message;
    } else {
      const ins = await sb.from('memorandums').insert({
        memo_no: document.getElementById('memo-no').value.trim(),
        title: document.getElementById('title').value.trim(),
        memo_date: document.getElementById('date').value,
        file_path: path,
        file_name: file.name,
        file_type: file.type || null,
        file_size: file.size,
      });

      if (ins.error) {
        await sb.storage.from(BUCKET).remove([path]); // undo the upload
        msg.textContent = ins.error.message;
      } else {
        form.reset();
        msg.textContent = 'Uploaded!';
        loadMemos();
      }
    }

    btn.disabled = false;
    btn.textContent = 'Upload';
  });

  // Logout
  document.getElementById('logout-btn').addEventListener('click', async () => {
    await sb.auth.signOut();
    location.replace('/login');
  });

  loadMemos();
})();
