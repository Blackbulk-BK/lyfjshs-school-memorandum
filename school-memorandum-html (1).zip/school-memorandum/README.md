# Luis Y. Ferrer Jr. Senior High School — School Memorandum

Website where one uploader posts school memorandums (PDF, Excel, Word, any file) and everyone can view, search, and share them.

**Stack:** HTML + CSS + JavaScript (browser) · Node.js + Express (server) · Supabase (database, login, file storage) · Nodemailer (Gmail)

## Setup

1. Create a free project at https://supabase.com
2. Authentication > Users > Add user (the uploader). Then turn OFF "Allow new users to sign up".
3. Edit the email in `supabase/migrations/006_make_uploader_admin.sql`, then paste `supabase/schema.sql` in the SQL Editor and Run.
4. Copy `.env.example` to `.env` and fill it in (Gmail needs a 16-letter **App Password**).
5. Put the school logo at `public/logo.png`.
6. `npm install` then `npm start` and open http://localhost:3000

## Files

| File | Language | What it does |
|---|---|---|
| `server.js` | JavaScript (Node.js) | Runs the website, sends emails, fills the Facebook share title |
| `public/index.html` | HTML | Home: list + search |
| `public/memo.html` | HTML | One memorandum: preview, download, share |
| `public/login.html` | HTML | Uploader login |
| `public/admin.html` | HTML | Upload / delete |
| `public/css/style.css` | CSS | Design |
| `public/js/*.js` | JavaScript (browser) | The behavior of each page |
| `supabase/*.sql` | SQL | Database, security, file storage |

## Deploy (free)

Use https://render.com : New > Web Service > connect the GitHub repo.
Build command: `npm install` · Start command: `npm start`
Add every variable from `.env.example` under Environment (set `SITE_URL` to the real website address).

## Adding many email recipients at once

Log in > Uploader page > **Email recipients** > Download the Excel template > fill in Name and Email > Upload it.
The website reads every email, skips duplicates and invalid rows, and saves them. When sharing a memorandum, press **Select all** to email everyone.
