// Node.js backend: serves the HTML pages + sends emails.
require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const { createClient } = require('@supabase/supabase-js');

const app = express();
const PORT = process.env.PORT || 3000;

// Accepts the names Supabase shows on its dashboard too
const SUPABASE_URL = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY =
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  process.env.SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const BATCH_SIZE = 50;     // recipients per email (hidden with BCC)
const MAX_RECIPIENTS = 400; // Gmail free limit is about 500 emails per day

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('Missing SUPABASE_URL or SUPABASE_PUBLISHABLE_KEY in .env');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

app.use(express.json());

// Gives the browser the (public) Supabase settings
app.get('/config.js', (req, res) => {
  res.type('application/javascript').send(
    `window.APP_CONFIG = ${JSON.stringify({ SUPABASE_URL, SUPABASE_ANON_KEY })};`
  );
});

// Memo page: fills in the title so Facebook shows it when shared
app.get('/memo/:id', async (req, res) => {
  const template = fs.readFileSync(path.join(__dirname, 'public', 'memo.html'), 'utf8');
  let title = 'School Memorandum';
  try {
    const { data: memo } = await supabase
      .from('memorandums').select('memo_no,title').eq('id', req.params.id).maybeSingle();
    if (memo) title = `${memo.memo_no} — ${memo.title}`;
  } catch (e) { /* keep default title */ }

  const site = process.env.SITE_URL || `${req.protocol}://${req.get('host')}`;
  const meta = `<title>${esc(title)}</title>
  <meta property="og:title" content="${esc(title)}">
  <meta property="og:description" content="Luis Y. Ferrer Jr. Senior High School — School Memorandum">
  <meta property="og:type" content="article">
  <meta property="og:url" content="${esc(site + req.originalUrl)}">`;

  res.send(template.replace('<!--META-->', meta));
});

app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

// Email sharing (only the logged-in uploader)
app.post('/api/send-email', async (req, res) => {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Not logged in.' });

  // Act as the logged-in user so the database rules (RLS) apply
  const userDb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: `Bearer ${token}` } },
  });

  const { data: userData } = await userDb.auth.getUser(token);
  if (!userData || !userData.user) return res.status(401).json({ error: 'Not logged in.' });

  const { data: admin } = await userDb.from('admins').select('user_id').maybeSingle();
  if (!admin) return res.status(403).json({ error: 'Not allowed.' });

  const memoId = req.body.memoId;
  const extraRaw = Array.isArray(req.body.recipients) ? req.body.recipients : [];

  const { data: memo } = await userDb.from('memorandums').select('*').eq('id', memoId).maybeSingle();
  if (!memo) return res.status(404).json({ error: 'Memorandum not found.' });

  // The built-in email ALWAYS receives it (falls back to the sending Gmail)
  const defaultTo = (process.env.MEMO_DEFAULT_RECIPIENT || process.env.GMAIL_USER || '').trim();
  if (!EMAIL_RE.test(defaultTo)) {
    return res.status(500).json({ error: 'MEMO_DEFAULT_RECIPIENT is not set correctly.' });
  }

  const extra = Array.from(new Set(
    extraRaw.map((e) => String(e).trim().toLowerCase()).filter((e) => EMAIL_RE.test(e))
  )).filter((e) => e !== defaultTo.toLowerCase());

  if (extra.length > MAX_RECIPIENTS) {
    return res.status(400).json({ error: `Too many recipients at once (max ${MAX_RECIPIENTS}).` });
  }

  const site = process.env.SITE_URL || `${req.protocol}://${req.get('host')}`;
  const pageUrl = `${site}/memo/${memo.id}`;
  const fileLink = userDb.storage.from('memorandums').getPublicUrl(memo.file_path).data.publicUrl;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD },
  });

  const subject = `${memo.memo_no} — ${memo.title}`;
  const html = `
    <p>A school memorandum has been shared with you.</p>
    <p><strong>${esc(memo.memo_no)}</strong><br>${esc(memo.title)}<br>${esc(memo.memo_date)}</p>
    <p><a href="${esc(pageUrl)}">View the memorandum</a><br>
       <a href="${esc(fileLink)}">Download the file</a></p>`;

  // Split into groups: the built-in email is in "to" of the first message,
  // everybody else is in BCC so they cannot see each other's emails.
  const groups = [];
  for (let i = 0; i < extra.length; i += BATCH_SIZE) groups.push(extra.slice(i, i + BATCH_SIZE));
  if (groups.length === 0) groups.push([]);

  let sent = 0;
  for (let g = 0; g < groups.length; g++) {
    const bcc = groups[g];
    const first = g === 0;
    const emailed = first ? [defaultTo, ...bcc] : bcc;

    try {
      await transporter.sendMail({
        from: `"Luis Y. Ferrer Jr. SHS - School Memorandum" <${process.env.GMAIL_USER}>`,
        to: first ? defaultTo : process.env.GMAIL_USER,
        bcc: bcc.length ? bcc : undefined,
        subject,
        html,
      });
      sent += emailed.length;
      await userDb.from('share_logs').insert(
        emailed.map((email) => ({ memorandum_id: memo.id, recipient_email: email, status: 'sent' }))
      );
    } catch (err) {
      await userDb.from('share_logs').insert(
        emailed.map((email) => ({
          memorandum_id: memo.id,
          recipient_email: email,
          status: 'failed',
          error_message: String(err).slice(0, 300),
        }))
      );
    }
  }

  if (sent === 0) return res.status(500).json({ error: 'Email failed. Check the Gmail settings.' });
  res.json({ sent });
});

// Everything else in /public (index.html, css, js, logo.png)
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => console.log(`School Memorandum running on http://localhost:${PORT}`));
