# Luis Y. Ferrer Jr. Senior High School — School Memorandum

Website where one uploader posts school memorandums (PDF, Excel, Word, any file) and everyone can view, search, and share them.

**Stack:** HTML + CSS + JavaScript (browser) · Node.js + Express (server) · Supabase (database, login, file storage) · Brevo (email sending)

## 1. Supabase (once)

1. Create a free project at https://supabase.com
2. **Authentication > Users > Add user**: enter the uploader's email + password, tick *Auto Confirm User*.
3. **Authentication > Sign In / Providers**: turn OFF *Allow new users to sign up*.
4. Open `supabase/schema.sql`, change `UPLOADER_EMAIL_HERE@gmail.com` (last lines) to the uploader's email.
5. **SQL Editor > New query**: paste the whole `schema.sql` > **Run**. (Run it only once.)

## 2. Brevo (email sending)

1. Sign up at https://www.brevo.com
2. **Senders, Domains & IPs > Senders > Add a sender** and verify your school Gmail with the code Brevo emails you.
3. **SMTP & API > SMTP** > copy your login and **Generate a new SMTP key**.

## 3. Run it on your computer

1. Install Node.js (LTS) from https://nodejs.org
2. Copy `.env.example` to `.env` and fill it in.
3. Put the school logo at `public/logo.png`
4. In the project folder:
   ```
   npm install
   npm start
   ```
5. Open http://localhost:3000 — the uploader logs in at http://localhost:3000/login

## Files

| File | Language | What it does |
|---|---|---|
| `server.js` | JavaScript (Node.js) | Runs the website, sends emails, sets the Facebook share title |
| `public/index.html` | HTML | Home: list + search |
| `public/memo.html` | HTML | One memorandum: preview, download, share |
| `public/login.html` | HTML | Uploader login |
| `public/admin.html` | HTML | Upload / delete / email recipients |
| `public/css/style.css` | CSS | Design |
| `public/js/*.js` | JavaScript (browser) | The behavior of each page |
| `supabase/*.sql` | SQL | Database, security, file storage |

## Adding many email recipients at once

Log in > **Uploader** page > **Email recipients** > Download the Excel template > fill in Name and Email > Upload it.
Duplicates and invalid rows are skipped. When sharing a memorandum press **Select all** to email everyone.

## Put it online (free)

1. Push the project to GitHub (`.env` is NOT uploaded; it is in `.gitignore`).
2. https://render.com > New > **Web Service** > pick the repo.
   Build command: `npm install` · Start command: `npm start`
3. Under **Environment**, add every variable from your `.env`.
4. When Render gives you the address (like `https://xxxx.onrender.com`), set `SITE_URL` to it.
5. Facebook sharing only works on the online address, not on localhost.
